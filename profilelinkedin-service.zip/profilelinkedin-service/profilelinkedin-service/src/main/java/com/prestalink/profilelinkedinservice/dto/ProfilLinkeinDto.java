package com.prestalink.profilelinkedinservice.dto;

import java.util.HashMap;

public class ProfilLinkeinDto {
    private Long id;
    private String titreDeProfile;
    private String lieu;
    private int connexion;
    private String nomDeProfile;
    private HashMap<String,String> exp;
    private HashMap<String,String> educ;
}
